#include "World.h"


void World::addObject(Object* obj){
    objects.push_back(obj);
}

World::World() : main(0){
    fillObjects();
}

void World::fillObjects(){
    Point nave_point(0,0,0);
    Point planet_point(10,10,0);
    Point satelite_point(12,8,0);
    Point metero_point(-8,5,0);

    Object* nave = new Nave();
    nave->setPosition(nave_point);

    /*Object* meteoro = new Meteoro(nave_point);
    meteoro->setPosition(metero_point);
    meteoro->setVelocity(0.1);

    Object* planeta = new Planeta(nave_point);
    meteoro->setPosition(planet_point);
    meteoro->setVelocity(0.1);

    Object* satelite = new Satelite(planet_point);
    satelite->setPosition(satelite_point);
    satelite->setVelocity(0.1);

    addObject(nave);
    addObject(meteoro);
    addObject(satelite);
    addObject(planeta);*/
    addObject(nave);
    main = nave;
}

World::~World(){
    for(Object* obj : objects){
        delete obj;
    }
    objects.clear();
}

Object* World::getMainObject(){
    return main;
} 

void World::draw(){
    for(Object* object : objects){
        object->draw();
    }
} 

void World::update(){
    for(Object * object : objects){
        object->update();
    }
}